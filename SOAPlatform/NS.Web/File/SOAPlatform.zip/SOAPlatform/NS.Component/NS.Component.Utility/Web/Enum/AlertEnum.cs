﻿using System;

namespace NS.Component.Utility
{
    public enum AlertEnum
    {
        Default,
        Success,
        Info,
        Danger,
        Error
    }
}
