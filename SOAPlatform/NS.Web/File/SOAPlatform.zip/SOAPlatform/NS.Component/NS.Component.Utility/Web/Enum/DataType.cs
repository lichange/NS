﻿using System;

namespace NS.Component.Utility
{
    /// <summary>
    /// 单元格值类型（日期作为文本处理）
    /// </summary>
    public enum DataType
    {
        String = 0,
        Number = 1
    }
}