﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NS.Component.Utility
{
    /// <summary>
    /// 拼接表单帮助类（返回html）
    /// </summary>
    public class BuildFormHelper
    {
        
    }
}
