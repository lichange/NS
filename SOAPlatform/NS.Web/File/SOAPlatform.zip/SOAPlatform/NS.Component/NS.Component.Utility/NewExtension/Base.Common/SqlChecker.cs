﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NS.Component.Utility.Base.Helper
{
    /// <summary>
    /// 防SQL注入检查器
    /// </summary>
    public class SqlChecker
    {
    }
}
