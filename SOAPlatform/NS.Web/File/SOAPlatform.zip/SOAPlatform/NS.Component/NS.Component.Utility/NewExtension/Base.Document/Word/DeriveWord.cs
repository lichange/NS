﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace NS.Component.Utility
{
    /// <summary>
    /// 导出Word文件
    /// </summary>
    public class DeriveWord
    {
        /// <summary>
        /// 把DataTable导出为Word文件
        /// </summary>
        /// <param name="page">Page</param>
        /// <param name="fileName">Word文件名(不包括后缀*.doc)</param>
        /// <param name="dtbl">将要被导出的DataTable对象</param>
        /// <returns></returns>
        public static bool DataTableToWord(HttpResponse response, string fileName, DataTable dtbl)
        {
            response.Clear();
            response.Headers.Add("Cache-Control", "max-age=60");
            response.Headers.Add("Content-Disposition", "attachment;filename=" + fileName + ".doc");
            response.ContentType = "application/ms-word;charset=utf-8";
            //page.EnableViewState = false;
            response.WriteAsync(DataTableToHtmlTable(dtbl));
            response.StatusCode = StatusCodes.Status200OK;
            return true;
        }

        /// <summary>
        /// 把DataTable转换成Html的Table
        /// </summary>
        /// <param name="dataTable">DataTable对象</param>
        /// <returns></returns>
        public static string DataTableToHtmlTable(DataTable dataTable)
        {
            StringBuilder sBuilder = new StringBuilder();

            sBuilder.Append("<table cellspacing=\"0\" rules=\"all\" border=\"1\" style=\"border-collapse:collapse;\">");
            foreach (DataRow dr in dataTable.Rows)
            {
                sBuilder.Append("<tr>");
                foreach (DataColumn dc in dataTable.Columns)
                {
                    if (dc.ColumnName.Equals(""))
                    {
                        sBuilder.Append(string.Format("<td>{0}</td>", dr[dc].ToString()));
                    }
                    else
                    {
                        sBuilder.Append(string.Format("<td>{0}</td>", dr[dc].ToString()));// style='vnd.ms-excel.numberformat:@'
                    }
                }
                sBuilder.Append("</tr>");
            }
            sBuilder.Append("</table");
            return sBuilder.ToString();
        }
    }
}
