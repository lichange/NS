﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NS.Component.Data
{
    /// <summary>
    /// 
    /// </summary>
    public enum ChangeType
    {
        /// <summary>
        /// 添加
        /// </summary>
        Add,
        /// <summary>
        /// 淇敼
        /// </summary>
        Update,
        /// <summary>
        /// 鍒犻櫎
        /// </summary>
        Delete
    }
}
