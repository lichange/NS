//using System.ServiceModel;

//namespace NS.Component.NHibernate
//{
//    public class NHibernateContext
//    {
//        public static NHibernateContextExtension Current()
//        {

//            return OperationContext.Current.
//                    InstanceContext.Extensions.
//                    Find<NHibernateContextExtension>();
//        }
//    }
//}