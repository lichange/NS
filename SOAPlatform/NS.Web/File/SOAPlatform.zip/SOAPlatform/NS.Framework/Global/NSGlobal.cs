﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace NS.Framework.Global
{
    public class NSGlobal
    {
        /// <summary>
        /// 执行初始化前必须将NSGlobal类中的注入方法调用完毕
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public static void Init(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseStaticHttpContext();

            NSWebPath.HostEnv = env;
        }

        public static void InjectHttpContext(IServiceCollection services)
        {
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        }
    }
}
