﻿namespace EmitMapper.Mappers
{
    /// <summary>
    /// Mapper for classes
    /// </summary>
    internal abstract class MapperForClassImpl : ObjectsMapperBaseImpl
    {

    }
}