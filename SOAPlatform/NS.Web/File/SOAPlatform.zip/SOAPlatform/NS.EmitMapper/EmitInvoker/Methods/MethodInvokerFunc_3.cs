﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmitMapper.EmitInvoker
{
    public abstract class MethodInvokerFunc_3 : MethodInvokerBase
    {
        public abstract object CallFunc(object param1, object param2, object param3);
    }
}
