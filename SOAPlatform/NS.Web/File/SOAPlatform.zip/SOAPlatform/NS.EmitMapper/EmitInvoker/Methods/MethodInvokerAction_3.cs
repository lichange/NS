﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmitMapper.EmitInvoker
{
    public abstract class MethodInvokerAction_3 : MethodInvokerBase
    {
        public abstract void CallAction(object param1, object param2, object param3);
    }
}
