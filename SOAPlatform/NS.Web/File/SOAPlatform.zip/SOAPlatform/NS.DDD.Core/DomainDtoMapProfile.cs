﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS.DDD.Core
{
    public abstract class DomainDtoMapProfile
    {
        public abstract void Configure();
    }
}
